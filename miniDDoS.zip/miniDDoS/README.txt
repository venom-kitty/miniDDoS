*note that this program is called *MINI*ddoser.

this program doesn't ddos, instead it repeatedly pings the IP address. If you are looking to
seriously DDoS someone, then do not use this program. This program is mostly made just
because i was bored and was too lazy to program real DDoSers.

==============================================================================================

Thank you for using miniDDoS!